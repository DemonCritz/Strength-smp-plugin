# StrengthSMP (Paper plugin)

A starter Java plugin for a Minecraft Strength SMP server.

## Features
- Players start with 0 strength by default.
- Player kills award strength.
- Deaths remove strength.
- Strength is saved in `plugins/StrengthSMP/strength.yml`.
- `/strength` and `/strength <player>`
- `/strength top`
- Admin commands: `/strength set <player> <amount>`, `/strength add <player> <amount>`, `/strength reload`
- Optional ban-on-elimination setting.

## Build
1. Install JDK 21 and IntelliJ IDEA.
2. Open this folder as a Gradle project.
3. Let Gradle sync and download dependencies.
4. Run `gradle build` (or use the Gradle panel in IntelliJ).
5. Find `build/libs/StrengthSMP-1.0.0.jar`.
6. Back up your server, copy the JAR into the server's `plugins` folder, and restart.

## Important
- This project targets Paper API `1.21.11-R0.1-SNAPSHOT`. Change the dependency in `build.gradle` to match your server's supported Paper API version if needed.
- `ban-on-elimination` defaults to `false` so players are not accidentally banned during testing. Set it to `true` only if you want the configured threshold to trigger a ban.
- Test on a private test server first. This is a starter implementation, not a guarantee of compatibility with every fork or version.
