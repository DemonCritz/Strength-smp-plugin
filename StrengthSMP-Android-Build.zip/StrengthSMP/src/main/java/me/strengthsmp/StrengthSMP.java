package me.strengthsmp;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public final class StrengthSMP extends JavaPlugin implements Listener {
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "strength.yml");
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().severe("Could not create plugin data folder.");
        }
        loadData();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("strength")).setExecutor(this);
        getLogger().info("StrengthSMP enabled.");
    }

    @Override
    public void onDisable() {
        saveData();
    }

    private void loadData() {
        if (!dataFile.exists()) {
            try {
                if (!dataFile.createNewFile()) getLogger().warning("Could not create strength.yml.");
            } catch (IOException e) {
                getLogger().severe("Could not create strength.yml: " + e.getMessage());
            }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Could not save strength.yml: " + e.getMessage());
        }
    }

    private int startingStrength() {
        return getConfig().getInt("starting-strength", 0);
    }

    private int getStrength(UUID uuid) {
        String key = uuid.toString();
        if (!data.contains(key)) {
            data.set(key, startingStrength());
            saveData();
        }
        return data.getInt(key, startingStrength());
    }

    private void setStrength(UUID uuid, int value) {
        data.set(uuid.toString(), value);
        saveData();
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private String prefix() {
        return color(getConfig().getString("messages.prefix", "&6[Strength] &r"));
    }

    private void tell(CommandSender sender, String message) {
        sender.sendMessage(prefix() + color(message));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        getStrength(player.getUniqueId());
        int value = getStrength(player.getUniqueId());
        int threshold = getConfig().getInt("elimination-at-or-below", -10);
        if (getConfig().getBoolean("ban-on-elimination", false) && value <= threshold) {
            Bukkit.getBanList(BanList.Type.NAME).addBan(player.getName(),
                    "Eliminated: strength reached " + threshold, null, "StrengthSMP");
            player.kickPlayer(color("&cYou have been eliminated from the Strength SMP."));
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        int penalty = Math.max(0, getConfig().getInt("death-penalty", 1));
        int victimStrength = getStrength(victim.getUniqueId()) - penalty;
        setStrength(victim.getUniqueId(), victimStrength);
        tell(victim, "&cYou lost " + penalty + " strength. Current strength: &f" + victimStrength);

        if (killer != null && !killer.getUniqueId().equals(victim.getUniqueId())) {
            int reward = Math.max(0, getConfig().getInt("kill-reward", 1));
            int killerStrength = getStrength(killer.getUniqueId()) + reward;
            setStrength(killer.getUniqueId(), killerStrength);
            tell(killer, "&aYou gained " + reward + " strength for killing " + victim.getName()
                    + ". Current strength: &f" + killerStrength);
        }

        int threshold = getConfig().getInt("elimination-at-or-below", -10);
        if (getConfig().getBoolean("ban-on-elimination", false) && victimStrength <= threshold) {
            Bukkit.getScheduler().runTask(this, () -> {
                Bukkit.getBanList(BanList.Type.NAME).addBan(victim.getName(),
                        "Eliminated: strength reached " + threshold, null, "StrengthSMP");
                victim.kickPlayer(color("&cYou have been eliminated from the Strength SMP."));
            });
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                tell(sender, "Console: use /strength <player> to check a player's strength.");
                return true;
            }
            tell(player, "Your strength: &e" + getStrength(player.getUniqueId()));
            return true;
        }

        if (args[0].equalsIgnoreCase("top")) {
            List<Map.Entry<String, Integer>> entries = data.getKeys(false).stream()
                    .filter(key -> {
                        try { UUID.fromString(key); return true; }
                        catch (IllegalArgumentException ex) { return false; }
                    })
                    .map(key -> Map.entry(key, data.getInt(key)))
                    .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                    .limit(10)
                    .collect(Collectors.toList());

            tell(sender, "&6--- Strength Top 10 ---");
            int rank = 1;
            for (Map.Entry<String, Integer> entry : entries) {
                String name = Bukkit.getOfflinePlayer(UUID.fromString(entry.getKey())).getName();
                tell(sender, "&e" + rank++ + ". &f" + (name == null ? entry.getKey() : name)
                        + " &7- &a" + entry.getValue());
            }
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("strengthsmp.admin")) {
                tell(sender, "&cYou don't have permission.");
                return true;
            }
            reloadConfig();
            tell(sender, "&aConfig reloaded.");
            return true;
        }

        if (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("add")) {
            if (!sender.hasPermission("strengthsmp.admin")) {
                tell(sender, "&cYou don't have permission.");
                return true;
            }
            if (args.length != 3) {
                tell(sender, "Usage: /strength " + args[0] + " <player> <amount>");
                return true;
            }
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            if (!target.hasPlayedBefore() && !target.isOnline()) {
                tell(sender, "&cThat player has not joined before.");
                return true;
            }
            int amount;
            try {
                amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException ex) {
                tell(sender, "&cAmount must be a whole number.");
                return true;
            }
            int value = args[0].equalsIgnoreCase("set")
                    ? amount : getStrength(target.getUniqueId()) + amount;
            setStrength(target.getUniqueId(), value);
            tell(sender, "&aSet " + target.getName() + "'s strength to " + value + ".");
            if (target.getPlayer() != null) {
                tell(target.getPlayer(), "&eYour strength is now " + value + ".");
            }
            return true;
        }

        if (args.length == 1) {
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
            if (!target.hasPlayedBefore() && !target.isOnline()) {
                tell(sender, "&cThat player has not joined before.");
                return true;
            }
            tell(sender, "&e" + target.getName() + "'s strength: &f" + getStrength(target.getUniqueId()));
            return true;
        }

        tell(sender, "Commands: /strength, /strength <player>, /strength top");
        tell(sender, "Admin: /strength set <player> <amount>, /strength add <player> <amount>, /strength reload");
        return true;
    }
}
